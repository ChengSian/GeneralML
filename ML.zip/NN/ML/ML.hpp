//
//  ML.hpp
//  ML
//
//  Created by Hans on 2017/5/26.
//  Copyright © 2017年 Hans. All rights reserved.
//

#ifndef ML_hpp
#define ML_hpp

#include <stdio.h>
#include <cstdarg>

#define RANDOM_WEIGHT

#if defined __unix__ || defined __APPLE__ || defined _WIN32
    #include <iostream>
    #include <iomanip>
    #include <math.h>
    #define debug_double(msg, n) {std::cout << std::setprecision(n) << msg;}
    #define debug(msg)           {std::cout << msg;}
    #define endl                 std::endl
#else
    #include <Arduino.h>
    #include <math.h>
    #define debug_double(msg, n) {debug(msg, n);}
    #define debug(msg)           {Serial.print(msg);}
    #define endl                 "\n"
#endif

#ifdef RANDOM_WEIGHT
#define init_weight()  ((rand() % 100) / 150.0)
#else
#define init_weight()  0.01
#endif

typedef float MLType;
typedef uint  MLClassType;

struct ML_Node {
    MLType *weights;
    MLType error;
    unsigned int size;
};

struct ML_Layer {
    MLType *input;
    ML_Node *nodes;
    uint size;
};

class ML{
public:
    ML(uint neural_size, ...);
    ~ML();
    void Train(MLType *input, MLClassType *target, MLType learnRate);
    MLType* Predict(MLType *input);
//    MLType** ExportWeights();
//    void LoadWeights(MLType** weights);
    uint NetSize();
    void printNet();
    MLType Error(MLClassType *output);
    MLClassType* Classify();
private:
    MLType sigmonid(MLType z);
    ML_Layer* neural;
    uint size;
    uint input;
    uint output;
    MLType* outputs;
};

#endif /* ML_hpp */
